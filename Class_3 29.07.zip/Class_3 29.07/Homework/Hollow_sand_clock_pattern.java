import java.util.Scanner;

public class Hollow_sand_clock_pattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of rows: ");
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < i; j++)
                System.out.print("   ");
            for (int j = 0; j < 2 * (n - i) - 1; j++) {
                if (i == 0 || i == n - 1 || j == 0 || j == 2 * (n - i) - 2)
                    System.out.print(" * ");
                else
                    System.out.print("   ");
            }
            System.out.println();
        }
        for (int i = n - 2; i >= 0; i--) {
            for (int j = 0; j < i; j++)
                System.out.print("   ");
            for (int j = 0; j<2*(n-i)-1; j++) {
                if (i == 0 || j == 0 || j == 2*(n - i)-2)
                    System.out.print(" * ");
                else
                    System.out.print("   ");
            }
            System.out.println();
        }
        sc.close();
    }
}
