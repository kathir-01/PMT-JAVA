import java.util.Scanner;

public class Find_Even_Digit_Num {
     public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter array size: ");
        int n = sc.nextInt();
        int[] nums = new int[n];
        System.out.print("Enter array elements: ");
        for (int i = 0; i < n; i++) {
            nums[i] = sc.nextInt();
        }
        int count = 0;
        for (int num : nums) {
            int digits = 0;
            int temp = num;
            while (temp > 0) {
                digits++;
                temp /= 10;
            }
            if (digits % 2 == 0) {
                count++;
            }
        }
        System.out.println("Count = " + count);
        sc.close();
    }
}
