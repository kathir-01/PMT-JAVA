// Using Two Pointer Approach

import java.util.Scanner;

public class reverse_arr {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the num: ");
        int n=sc.nextInt();
        int[] a=new int[n];
        System.out.print("Enter the Array Elements: ");
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        int l=0,r=n-1,t;
        while(l<r){
            t=a[l];
            a[l]=a[r];
            a[r]=t;
            l++;
            r--;
        }
        System.out.println("Array After Reversing: ");
        for(int i=0;i<n;i++){
            System.out.print(a[i]+" ");
        }
        sc.close();
    }
}
