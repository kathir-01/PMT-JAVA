import java.util.Scanner;

public class Max_Min_array {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Size of the elements: ");
        int n=sc.nextInt();
        System.out.print("Enter Array elements: ");
        int[] a= new int[n];
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        int max=a[0],min=a[0];
        for(int i=1;i<n;i++){
            if(a[i]>max) max=a[i];
            if(a[i]<min) min=a[i];
        }
        System.out.println("Maximum Elements: "+ max);
        System.out.println("Minimum Elements: "+ min);
        sc.close();
    }
}
