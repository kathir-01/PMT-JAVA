import java.util.Scanner;

public class Left_rotation {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the num: ");
        int n=sc.nextInt();
        System.out.print("Enter the Array Elements: ");
        int[] a=new int[n];
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        System.out.print("Enter the number of rotations: ");
        int r=sc.nextInt();
        r=r%n;
        for(int i=0;i<r;i++){
            int t=a[0];
            for(int j=0;j<n-1;j++){
                a[j]=a[j+1];
            }
            a[n-1]=t;
        }
        System.out.println("Array After Left Rotation: ");
        for(int i=0;i<n;i++){   
            System.out.print(a[i]+" ");
        }
        sc.close();
    }
}
