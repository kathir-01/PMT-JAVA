import java.util.Scanner;

public class Arrow {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a Num: ");
        int n=sc.nextInt();
        int r,c;
        for(r=1;r<n;r++){
            for(c=1;c<=n;c++){
                if(r==n) System.out.print(" * ");
                else System.out.print("   ");
            }
            for(c=1;c<=r;c++){
                System.out.print(" * ");
            }
            System.out.println();
        }
    for(r=n;r>=1;r--){
            for(c=1;c<=n;c++){
                if(r==n) System.out.print(" * ");
                else System.out.print("   ");
            }
            for(c=1;c<=r;c++){
                System.out.print(" * ");
            }
            System.out.println();
        }
        sc.close();
    }
}
