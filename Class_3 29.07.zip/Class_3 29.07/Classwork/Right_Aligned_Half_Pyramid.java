import java.util.Scanner;

public class Right_Aligned_Half_Pyramid {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a Num: ");
        int n=sc.nextInt();
        int r,c;
        for(r=1;r<=n;r++){
            for(c=1;c<=n-r;c++){
                System.out.print("   ");
            }
            for(c=1;c<=r;c++){
                System.out.print(" * ");
            }
            System.out.println();
        }
        sc.close();
    }
}
