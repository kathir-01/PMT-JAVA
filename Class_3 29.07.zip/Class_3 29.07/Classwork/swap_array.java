import java.util.Scanner;

public class swap_array {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the num: ");
        int n=sc.nextInt();
        int[] a=new int[n];
        System.out.print("Enter the Array Elements: ");
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        System.out.print("Enter 1st index: ");
        int i1=sc.nextInt();
        System.out.print("Enter 2nd index: ");
        int i2=sc.nextInt();
        if(i1<0 || i1>=n || i2<0 || i2>=n) System.out.println("Invalid Index");
        else{
            int t=a[i1];
            a[i1]=a[i2];
            a[i2]=t;
        }
        System.out.println("Array After Swapping: ");
        for(int i=0;i<n;i++){
            System.out.print(a[i]+" ");
        }
        sc.close();
    }
}
