import java.util.Scanner;

public class Right_rotation {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the num: ");
        int n=sc.nextInt();
        System.out.print("Enter the Array Elements: ");
        int[] a=new int[n];
        for(int i=0;i<n;i++){
            a[i]=sc.nextInt();
        }
        System.out.print("Enter the number of rotations: ");
        int r=sc.nextInt();
        r=r%n;
        for(int i=0;i<r;i++){
            int t=a[n-1];
            for(int j=n-1;j>0;j--){
                a[j]=a[j-1];
            }
            a[0]=t;
        }
        System.out.print("Array After Right Rotation: ");
        for(int i=0;i<n;i++){
            System.out.print(a[i]+" ");
        }
        sc.close();
    }
}