import java.util.Scanner;
public class hollow_sqr_diagonal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of rows: ");
        int n = sc.nextInt();
        for (int r= 1; r <= n; r++) {
            for (int c = 1; c <= n; c++) {
                if(r==1 || c==n || r==n || c==1 || r==c || c==n-r+1)
                    System.out.print(" * ");
                else
                    System.out.print("   ");
            }
            System.out.println();
        }
        sc.close();
    }
}
