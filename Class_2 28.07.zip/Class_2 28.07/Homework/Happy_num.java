import java.util.Scanner;

public class Happy_num {
        public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n = sc.nextInt();
        int t=n, s=0;
        while(t!=1 && t!=4){
            s=0;
            while(t>0){
                int d=t%10;
                s+=d*d;
                t/=10;
            }
            t=s;
        }
        if(t==1) System.out.println(n+" is a happy number");
        else System.out.println(n+" is not a happy number");
        sc.close();

    }
}