import java.util.Scanner;

public class Magic_num {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n = sc.nextInt();
        int t=n, s=0;
        while(t>0){
            int d=t%10;
            s+=d;
            t/=10;
        }
        if(n%s==0) System.out.println(n+" is a magic number.");
        else System.out.println(n+" is not a magic number.");
        sc.close();
    }
}
