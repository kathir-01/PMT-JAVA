import java.util.Scanner;

public class Armstrong {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n = sc.nextInt();
        int t=n, s=0;
        while(t!=0){
            int d=t%10;
            s+=d*d*d;
            t/=10;
        }
        if(s==n) System.out.println(n+" is an Armstrong number");
        else System.out.println(n+" is not an Armstrong number");
        sc.close();
    }
}
