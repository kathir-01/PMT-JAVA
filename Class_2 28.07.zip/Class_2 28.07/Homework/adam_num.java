import java.util.Scanner;

public class adam_num {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n = sc.nextInt();
        int sq=n*n;
        int t=n,r=0;
        while(t>0){
            r=r*10+t%10;
            t/=10;
        }
        int revsq=r*r;
        t=sq;
        int revsq1=0;
        while(t>0){
            revsq1=revsq1*10+t%10;
            t/=10;
        }
        if(revsq==revsq1) System.out.println(n+" is an Adam number");
        else System.out.println(n+" is not an Adam number");
        sc.close();
    }
}
