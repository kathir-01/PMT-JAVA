import java.util.Scanner;

public class Strong_num {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n = sc.nextInt();
        int t=n, s=0;
        while(t>0){
            int d=t%10;
            int f=1;
            for(int i=1;i<=d;i++) f*=i;
            s+=f;
            t/=10;
        }
        if(s==n) System.out.println(n+" is a strong number.");
        else System.out.println(n+" is not a strong number.");
        sc.close();
    }
}
