import java.util.Scanner;
public class fibonacci {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a num: ");
        int x = sc.nextInt();
        int a=0,b=1,i;
        for(i=2;i<=x;i++){
            int c=b;
            b=a+b;
            a=c;
        }
        System.out.println("Fibonacci of " + x + " is: " + b);
        sc.close();
    }
}
