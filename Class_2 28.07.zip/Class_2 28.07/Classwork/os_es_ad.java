import java.util.Scanner;
public class os_es_ad {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a num: ");
        int n=sc.nextInt();
        int a=0,b=0;
        while(n>0){
            int r=n%10;
            if(r%2==0) a+=r;
            else b+=r;
            n/=10;
        }
        System.out.println("Sum of even digits: "+a);
        System.out.println("Sum of odd digits: "+b);
        System.out.println("Absolute Difference: "+Math.abs(a-b));
        sc.close();
    }
}
