import java.util.Scanner;
public class rangeofprime {
     public static boolean primechk(int n) {
        if (n % 2 == 0 && n != 2) {
            return false;
        }
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Starting Range : ");
        int a = sc.nextInt();
        System.out.print("Enter Ending Range : ");
        int b = sc.nextInt();
        int i;
        for (i = a; i <= b; i++) {
            if (primechk(i)) {
                System.out.print(i + " ");
            }
        }
        sc.close();
    }
}
