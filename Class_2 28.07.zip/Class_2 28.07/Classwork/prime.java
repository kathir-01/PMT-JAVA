import java.util.Scanner;
public class prime {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int num = sc.nextInt();
        boolean a=true;
        int i=0;
        for(i=2;i*i<=num;i++){
            if(num%i==0){
                a=false;break;
            }
        }
        if(a) System.out.println(num + " is a prime number.");
        else System.out.println(num + " is not a prime number.");
        sc.close();
    }
}
