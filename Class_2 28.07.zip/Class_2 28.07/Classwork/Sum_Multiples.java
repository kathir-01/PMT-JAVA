import java.util.Scanner;
public class Sum_Multiples {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a num: ");
        int s=0;
        int num = sc.nextInt();
        for(int i=1;i<=num;i++){
            if(i%3==0 || i%5==0 || i%7==0) s+=i;
        }
        System.out.println("Sum of multiples: " + s);
        sc.close();
    }
}
