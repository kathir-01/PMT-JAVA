import java.util.Scanner;
public class Digit_seg {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a num: ");
        int num = sc.nextInt();
        while(num!=0){
            System.out.print(num%10+" ");
            num/=10;
        }
        sc.close();
    }
}
