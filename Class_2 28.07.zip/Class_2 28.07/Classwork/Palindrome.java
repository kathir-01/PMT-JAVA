import java.util.Scanner;
public class Palindrome {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a num :");
        int a = sc.nextInt();
        if(a<0){
            System.out.println("Invalid input");
            sc.close();
            return;
        }
        int org=a;
        int rev = 0;
        while(a>0){
            int rem = a%10;
            rev = rev*10 + rem;
            a/=10;
        }
        if(rev==org) System.out.println("Palindrome");
        else System.out.println("Not Palindrome");
        sc.close();
    }
}
