class Solution {
    public int maxArea(int[] l) {
        int n = l.length;
        int i = 0 , j = n-1;
        int m = -1;
        while(i<j){
            if(l[i]<l[j]){
                int t = l[i]*(j-i);
                if(m<t)m=t;
                i+=1;
            }
            else{
                int t = l[j]*(j-i);
                if(m<t)m=t;
                j-=1;
            }
        }
        return m;
    }
}