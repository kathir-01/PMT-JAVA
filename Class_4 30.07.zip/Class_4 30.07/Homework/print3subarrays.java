import java.util.Scanner;

public class print3subarrays {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Number : ");
        int n = sc.nextInt();
        System.out.print("Enter Values : ");
        int l[] = new int[n];
        for (int i = 0; i < n; i++) {
            l[i] = sc.nextInt();
        }

        for (int i = 0; i < n - 2; i++) {
            for (int j = i; j < i + 3; j++) {
                System.out.print(l[j] + " ");
            }
            System.out.println();
        }
        sc.close();
    }
}
