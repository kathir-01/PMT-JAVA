import java.util.Scanner;

public class sum_of_all_values_except_self {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Number : ");
        int n = sc.nextInt();
        System.out.print("Enter Values : ");
        int l[] = new int[n];
        for (int i = 0; i < n; i++) {
            l[i] = sc.nextInt();
        }
        int ans[]=new int[n];
        ans[0]=0;
        for(int i=1;i<n;i++){
            ans[i]=ans[i-1]+l[i-1];
        }
        int s = 0 ;
        for(int i=n-2;i>=0;i--){
            ans[i]+=s+l[i+1];
            s+=l[i+1];
        }
        for(int i:ans){
            System.out.print(i+" ");
        }
        sc.close();
    }
}
