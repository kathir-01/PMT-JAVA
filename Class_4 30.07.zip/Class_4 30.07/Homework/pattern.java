import java.util.Scanner;
public class pattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Number : ");
        int n = sc.nextInt();
        for(int i =0;i<n;i++){
            for(int j = 0;j<i;j++)System.out.print(" ");
            System.out.print("*");
            for(int j = 0;j<(n-i)*2-1;j++)System.out.print(" ");
            System.out.print("*");
            System.out.println();
        }
        for(int j =0;j<n;j++)System.out.print(" ");
        System.out.println("*");
        for(int i=n-1;i>=0;i--){
            for(int j = 0;j<i;j++)System.out.print(" ");
            System.out.print("*");
            for(int j = 0;j<(n-i)*2-1;j++)System.out.print(" ");
            System.out.print("*");
            System.out.println();
        }
        sc.close();
    }
}
