import java.util.Scanner;
public class  printallsubarrays{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Number : ");
        int n = sc.nextInt();
        System.out.print("Enter Values : ");
        int l[] = new int[n];
        for(int i = 0 ;i < n;i++){
            l[i]=sc.nextInt();
        }

        for(int i =0;i<n;i++){
            for(int j =i;j<n;j++){
                for(int k = i;k<j;k++){
                    System.out.print(l[k]+" ");
                }
                System.out.println();
            }
        }
        sc.close();
    }
}
