import java.util.Scanner;
public class suffix {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Number : ");
        int n = sc.nextInt();
        System.out.print("Enter Values : ");
        int l[] = new int[n];
        for(int i = 0 ;i < n;i++){
            l[i]=sc.nextInt();
        }
        int ans[]=new int[n];
        ans[n-1]=0;
        for(int i=n-2;i>=0;i--){
            ans[i]=ans[i+1]+l[i+1];
        }
        for(int i:ans){
            System.out.print(i+" ");
        }
        sc.close();
    }
}
