import java.util.Scanner;

public class Suffix_sum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int n = sc.nextInt();
        int[] arr = new int[n];
        System.out.print("Enter the elements: ");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        int[] suf= new int[n];
        suf[n - 1] = 0;
        for (int i = n - 2; i >= 0; i--) {
            suf[i] = suf[i + 1] + arr[i + 1];
        }
        System.out.print("Suffix Sum: ");
        for (int i = 0; i < n; i++) {
            System.out.print(suf[i] + " ");
        }
        sc.close();
    }
}
