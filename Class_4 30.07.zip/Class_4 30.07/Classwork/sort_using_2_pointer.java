import java.util.Scanner;

public class sort_using_2_pointer {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size: ");
        int size = sc.nextInt();
        int[] arr = new int[size];
        System.out.print("Enter the elements: ");
        for (int itr = 0; itr < size; itr++) {
            arr[itr] = sc.nextInt();
        }
        int c = 0;
        for (int s = 0; s < size; s++) {
            if (arr[s] % 10 != 0) {
                int temp = arr[s];
                for (int itr = s; itr > c; itr--) {
                    arr[itr] = arr[itr - 1];
                }
                arr[c] = temp;
                c++;
            }
        }
        System.out.print("Output: ");
        for (int ele : arr) {
            System.out.print(ele + " ");
        }
        sc.close();
    }
}