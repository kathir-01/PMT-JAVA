import java.util.Scanner;

public class Binary_search {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int n = sc.nextInt();
        int[] a = new int[n];
        System.out.print("Enter the elements in sorted order: ");
        for (int i = 0; i < n; i++) {
            a[i] = sc.nextInt();
        }
        int l=0, h=n-1, m;
        System.out.print("Enter the element to search: ");
        int x = sc.nextInt();
        while(l<=h){
            m=(l+h)/2;
            if(a[m]==x){
                System.out.println("Element found at index: " + m);
                sc.close();
                return;
            }
            else if(a[m]<x) l=m+1;
            else h=m-1;
        }
        System.out.println("Element not found in the array.");
        sc.close();
    }
}
