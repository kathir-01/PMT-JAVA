import java.util.Scanner;

public class prefix_sum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int n = sc.nextInt();
        int[] arr = new int[n];
        System.out.print("Enter the elements: ");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        int[] pre= new int[n];
        pre[0] = 0;
        for (int i = 1; i < n; i++) {
            pre[i] = pre[i - 1] + arr[i - 1];
        }
        System.out.print("Prefix Sum: ");
        for (int i = 0; i < n; i++) {
            System.out.print(pre[i] + " ");
        }
        sc.close();
    }
}
