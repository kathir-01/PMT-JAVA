import java.util.Scanner;

public class Product_of_Array_Except_Self {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int n = sc.nextInt();
        int[] a = new int[n];
        int[] b = new int[n];
        System.out.print("Enter the elements: ");
        for(int i = 0; i < n; i++){
            a[i] = sc.nextInt();
        }
        b[0]=1;
        for(int i=1;i<n;i++){
            b[i]=b[i-1]*a[i-1];
        }
        int r=1;
        for(int i=n-1;i>=0;i--){
            b[i]=b[i]*r;
            r=r*a[i];
        }
        System.out.print("The product of array except self is: ");
        for(int i = 0; i < n; i++){
            System.out.print(b[i] + " ");
        }
        sc.close();
    }
}
