import java.util.Scanner;

class Friends {
    String name;
    double ph_no;
    Friends(String name, double ph_no) {
        this.name = name;
        this.ph_no = ph_no;
    }
    void dis() {
        System.out.println("Name      : " + name);
        System.out.println("Phone No. : " + ph_no);
        System.out.println();
    }
}
public class Frnds{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Friends[] f = new Friends[5];
        for (int i = 0; i < 5; i++) {
            System.out.println("Enter details of Friend " + (i + 1));

            System.out.print("Enter Name : ");
            String name = sc.nextLine();
            System.out.print("Enter Phone Number : ");
            double phone = sc.nextDouble();
            sc.nextLine();
            f[i] = new Friends(name, phone);
            System.out.println();
        }
        System.out.println("FRIEND DETAILS");
        for (int i = 0; i < 5; i++) {
            f[i].dis();
        }
        sc.close();
    }
}