import java.util.*;
public class leap {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Date : ");
        int d = sc.nextInt();
        System.out.print("Enter Month : ");
        int m = sc.nextInt();
        System.out.print("Enter Year : ");
        int y = sc.nextInt();
        int leap = 0;
        int x = 0;
        if (y > 999 && y <= 9999) {
            if (y % 400 == 0) {
                leap = 1;
            } else if (y % 4 == 0) {
                if (y % 100 != 0) {
                    leap = 1;
                }
            }
        } else {
            System.out.println("Invalid Date");
            sc.close();
            return;
        }
        if (m >= 1 && m <= 12) {
            if (m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12) {
                x = 1;
            } else if (m == 2) {
                x = 2;
            }
        } else {
            System.out.println("Invalid Date");
            sc.close();
            return;
        }
        if (d >= 1) {
            if (x == 0 && d > 30) {
                System.out.println("Invalid Date");
                sc.close();
                return;
            }
            if (x == 1 && d > 31) {
                System.out.println("Invalid Date");
                sc.close();
                return;
            }
            if (x == 2) {
                if (leap == 0 && d > 28) {
                    System.out.println("Invalid Date");
                    sc.close();
                    return;
                } else if (leap == 1 && d > 29) {
                    System.out.println("Invalid Date");
                    sc.close();
                    return;
                }
            }
        }
        System.out.println("Valid Date");
        sc.close();
    }
}

