import java.util.Scanner;

public class Simple_cal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter 1st number: ");
        int a = sc.nextInt();
        System.out.print("Enter 2nd number: ");
        int b = sc.nextInt();
        System.out.print("Enter an operator (+, -, *, /): ");
        char op = sc.next().charAt(0);
        switch(op){
            case '+': System.out.println("Sum: "+(a+b)); break;
            case '-': System.out.println("Difference: "+(a-b)); break;
            case '*': System.out.println("Product: "+(a*b)); break;
            case '/': 
                if(b!=0) System.out.println("Quotient: "+(a/b));
                else System.out.println("Division by zero is not allowed");
                break;
            default: System.out.println("Invalid operator");
        }
        sc.close();
    }
}   

