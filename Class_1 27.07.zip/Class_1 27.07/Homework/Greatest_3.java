import java.util.Scanner;

public class Greatest_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter 3 numbers: ");
        int a=sc.nextInt();
        int b=sc.nextInt();
        int c=sc.nextInt();
        if(a>b){
            if(a>c) System.out.println(a+" is a greatest number");
            else System.out.println(c+" is a greatest number");
        }
        else{
            if(b>c) System.out.println(b+" is a greatest number");
            else System.out.println(c+" is a greatest number");
        }
        sc.close();
    }
}
