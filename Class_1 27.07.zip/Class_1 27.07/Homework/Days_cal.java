import java.util.Scanner;

public class Days_cal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a date (dd mm yyyy): ");
        String date = sc.nextLine();
        String[] d=date.split("-");
        int day=Integer.parseInt(d[0]);
        int month=Integer.parseInt(d[1]);
        int year=Integer.parseInt(d[2]);
        int[] days={31,28,31,30,31,30,31,31,30,31,30,31};
        if(year%4==0 && year%100!=0 || year%400==0){
            days[1]=29;
        }
        int cmp=0;
        for(int i=0;i<month-1;i++){
            cmp+=days[i];
        }
        cmp+=day;
        int tol=(days[1]==29)?366:365;
        int rem=tol-cmp;
        System.out.println("Days completed: "+cmp);
        System.out.println("Days remaining: "+rem);
        sc.close();
    }
}
